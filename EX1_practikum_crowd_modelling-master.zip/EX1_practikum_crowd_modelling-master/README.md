# practikum

Addition of new python file with Djikstra implemented
Creation of a test.py to test independently from the function file

Change of the Neighboor function in order to consider the corner problem arround an obstacle a pedestrian cannot go in diagonale

Change names of files
